public class Main {
    public static void main(String[] args) {
        // Create TaskManager
        TaskManager manager = new TaskManager();

        // Create some tasks
        Task task1 = new Task(1, "Task 1", "In Progress");
        Task task2 = new Task(2, "Task 2", "Completed");
        Task task3 = new Task(3, "Task 3", "Pending");

        // Add tasks
        manager.addTask(task1);
        manager.addTask(task2);
        manager.addTask(task3);

        // Traverse and print all tasks
        System.out.println("All Tasks:");
        manager.traverseTasks();

        // Search for a task
        System.out.println("Searching for task with ID 2:");
        Task foundTask = manager.searchTaskById(2);
        System.out.println(foundTask != null ? foundTask : "Task not found");

        // Delete a task
        System.out.println("Deleting task with ID 1:");
        boolean deleted = manager.deleteTaskById(1);
        System.out.println(deleted ? "Task deleted successfully" : "Task not found");

        // Traverse and print all tasks after deletion
        System.out.println("All Tasks after deletion:");
        manager.traverseTasks();
    }
}