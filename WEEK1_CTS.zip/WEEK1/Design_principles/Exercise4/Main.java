public class Main {
    public static void main(String[] args) {
        // Create EmployeeManager with a capacity of 5 employees
        EmployeeManager manager = new EmployeeManager(5);

        // Create some employees
        Employee emp1 = new Employee(1, "Alice", "Developer", 60000);
        Employee emp2 = new Employee(2, "Bob", "Manager", 80000);
        Employee emp3 = new Employee(3, "Charlie", "Analyst", 55000);

        // Add employees
        manager.addEmployee(emp1);
        manager.addEmployee(emp2);
        manager.addEmployee(emp3);

        // Traverse and print all employees
        System.out.println("All Employees:");
        manager.traverseEmployees();

        // Search for an employee
        System.out.println("Searching for employee with ID 2:");
        Employee foundEmp = manager.searchEmployeeById(2);
        System.out.println(foundEmp != null ? foundEmp : "Employee not found");

        // Delete an employee
        System.out.println("Deleting employee with ID 1:");
        boolean deleted = manager.deleteEmployeeById(1);
        System.out.println(deleted ? "Employee deleted successfully" : "Employee not found");

        // Traverse and print all employees after deletion
        System.out.println("All Employees after deletion:");
        manager.traverseEmployees();
    }
}