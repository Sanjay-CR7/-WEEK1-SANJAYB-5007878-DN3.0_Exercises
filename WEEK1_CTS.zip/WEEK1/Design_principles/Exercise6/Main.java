import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        // Create some books
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book(3, "1984", "George Orwell"));

        // Sort books by title for binary search
        Collections.sort(books, Comparator.comparing(Book::getTitle));

        // Create LibraryManager
        LibraryManager manager = new LibraryManager(books);

        // Test linear search
        System.out.println("Linear Search:");
        Book book1 = manager.linearSearchByTitle("1984");
        System.out.println(book1 != null ? book1 : "Book not found");

        // Test binary search
        System.out.println("Binary Search:");
        Book book2 = manager.binarySearchByTitle("To Kill a Mockingbird");
        System.out.println(book2 != null ? book2 : "Book not found");
    }
}