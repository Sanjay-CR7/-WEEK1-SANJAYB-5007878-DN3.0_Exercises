import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Create an array of products
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Table", "Furniture"),
            new Product(4, "Chair", "Furniture")
        };

        // For binary search, ensure the array is sorted by productId
        Arrays.sort(products, (p1, p2) -> Integer.compare(p1.getProductId(), p2.getProductId()));

        // Test linear search
        int searchId = 3;
        Product resultLinear = SearchUtils.linearSearch(products, searchId);
        System.out.println("Linear Search Result: " + (resultLinear != null ? resultLinear : "Product not found"));

        // Test binary search
        Product resultBinary = SearchUtils.binarySearch(products, searchId);
        System.out.println("Binary Search Result: " + (resultBinary != null ? resultBinary : "Product not found"));
    }
}