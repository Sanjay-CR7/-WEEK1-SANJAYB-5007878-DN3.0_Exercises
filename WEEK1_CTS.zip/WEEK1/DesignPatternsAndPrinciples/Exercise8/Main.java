public class Main {
    public static void main(String[] args) {
        // Create payment strategies
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "John Doe");
        PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com");

        // Create context with Credit Card payment strategy
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(100.00);

        // Change to PayPal payment strategy
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.executePayment(200.00);
    }
}