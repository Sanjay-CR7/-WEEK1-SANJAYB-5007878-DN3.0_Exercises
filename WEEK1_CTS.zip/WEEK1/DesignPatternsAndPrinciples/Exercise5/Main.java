public class Main {
    public static void main(String[] args) {
        // Basic email notifier
        Notifier notifier = new EmailNotifier();

        // Add SMS notification functionality
        notifier = new SMSNotifierDecorator(notifier);

        // Add Slack notification functionality
        notifier = new SlackNotifierDecorator(notifier);

        // Send notification via multiple channels
        notifier.send("Hello, this is a test notification.");
    }
}