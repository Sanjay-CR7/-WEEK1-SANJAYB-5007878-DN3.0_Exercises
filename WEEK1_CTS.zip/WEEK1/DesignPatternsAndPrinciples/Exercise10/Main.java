public class Main {
    public static void main(String[] args) {
        // Create a student model
        Student student = new Student("John Doe", 1, "A");

        // Create a view to display student details
        StudentView view = new StudentView();

        // Create a controller to manage the student and view
        StudentController controller = new StudentController(student, view);

        // Update view with initial student details
        controller.updateView();

        // Update student details using controller
        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("B");

        // Update view with modified student details
        controller.updateView();
    }
}