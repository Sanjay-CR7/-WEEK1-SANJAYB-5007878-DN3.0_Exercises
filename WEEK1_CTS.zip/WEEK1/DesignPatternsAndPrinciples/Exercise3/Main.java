public class Main {
    public static void main(String[] args) {
                Computer gamingPC = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setMotherboard("ASUS ROG")
                .setCoolingSystem("Liquid Cooling")
                .build();

        System.out.println("Gaming PC Configuration:");
        System.out.println("CPU: " + gamingPC.getCPU());
        System.out.println("RAM: " + gamingPC.getRAM());
        System.out.println("Storage: " + gamingPC.getStorage());
        System.out.println("Graphics Card: " + gamingPC.getGraphicsCard());
        System.out.println("Power Supply: " + gamingPC.getPowerSupply());
        System.out.println("Motherboard: " + gamingPC.getMotherboard());
        System.out.println("Cooling System: " + gamingPC.getCoolingSystem());
    }
}
