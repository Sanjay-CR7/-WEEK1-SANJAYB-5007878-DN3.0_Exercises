public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // Image is not loaded at this point
        image1.display(); // Image will be loaded and displayed here
        image1.display(); // Image will be displayed from cache

        // Image is not loaded at this point
        image2.display(); // Image will be loaded and displayed here
        image2.display(); // Image will be displayed from cache
    }
}