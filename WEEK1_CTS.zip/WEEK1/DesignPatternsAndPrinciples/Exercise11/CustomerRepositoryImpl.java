public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(int id) {
        // Simulate finding a customer from a database
        return new Customer(id, "John Doe"); // Example customer
    }
}