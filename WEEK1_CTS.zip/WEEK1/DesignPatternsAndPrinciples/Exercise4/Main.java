public class Main {
    public static void main(String[] args) {
        PaymentProcessor payPalProcessor = new PayPalAdapter(new PayPalPayment());
        PaymentProcessor stripeProcessor = new StripeAdapter(new StripePayment());
        PaymentProcessor squareProcessor = new SquareAdapter(new SquarePayment());

        // Using the PaymentProcessor interface to process payments
        payPalProcessor.processPayment(100.00);
        stripeProcessor.processPayment(200.00);
        squareProcessor.processPayment(300.00);
    }
}